# BC32_Capstone


Phước: 50% bài từ trên xuống
Sơn: 50% bài còn lại